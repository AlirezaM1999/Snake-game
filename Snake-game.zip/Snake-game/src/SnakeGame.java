public class SnakeGame {

    public static void main(String[] args) {

        try {
            new GameFrame();
        } catch (Exception e) {

        }
    }
}
